package com.example.mynotes;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelRekomendasi implements Parcelable{
    String nama_obat;
    String harga;
    String satuan;
    String gambar;
    String id_obat;

    public ModelRekomendasi() {

    }

    protected ModelRekomendasi(Parcel in) {
        nama_obat = in.readString();
        harga = in.readString();
        satuan = in.readString();
        gambar = in.readString();
        id_obat = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nama_obat);
        dest.writeString(harga);
        dest.writeString(satuan);
        dest.writeString(gambar);
        dest.writeString(id_obat);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelRekomendasi> CREATOR = new Creator<ModelRekomendasi>() {
        @Override
        public ModelRekomendasi createFromParcel(Parcel in) {
            return new ModelRekomendasi(in);
        }

        @Override
        public ModelRekomendasi[] newArray(int size) {
            return new ModelRekomendasi[size];
        }
    };

    public String getId_obat() {
        return id_obat;
    }

    public void setId_obat(String id_obat) {
        this.id_obat = id_obat;
    }

    public String getNama_obat() {
        return nama_obat;
    }

    public void setNama_obat(String nama_obat) {
        this.nama_obat = nama_obat;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

}
