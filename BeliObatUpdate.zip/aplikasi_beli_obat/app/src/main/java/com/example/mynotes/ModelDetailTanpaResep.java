package com.example.mynotes;

public class ModelDetailTanpaResep {
    String namaObat;
    String kuantitasObat;
    String hargaObat;
    String gambar;

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public String getKuantitasObat() {
        return kuantitasObat;
    }

    public void setKuantitasObat(String kuantitasObat) {
        this.kuantitasObat = kuantitasObat;
    }

    public String getHargaObat() {
        return hargaObat;
    }

    public void setHargaObat(String hargaObat) {
        this.hargaObat = hargaObat;
    }
}
