package com.example.mynotes;

public class ModelPesananObatAdmin {

    private String waktu, invoice, nama_user,nama_penerima, handphone, alamat, detail_alamat, harga, total_harga, jenis_pesan,
            status, waktu_bayar, gambar_resep, bukti_bayar, token;

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    public String getNama_user() {
        return nama_user;
    }

    public void setNama_user(String nama_user) {
        this.nama_user = nama_user;
    }

    public String getNama_penerima() {
        return nama_penerima;
    }

    public void setNama_penerima(String nama_penerima) {
        this.nama_penerima = nama_penerima;
    }

    public String getHandphone() {
        return handphone;
    }

    public void setHandphone(String handphone) {
        this.handphone = handphone;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getDetail_alamat() {
        return detail_alamat;
    }

    public void setDetail_alamat(String detail_alamat) {
        this.detail_alamat = detail_alamat;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getTotal_harga() {
        return total_harga;
    }

    public void setTotal_harga(String total_harga) {
        this.total_harga = total_harga;
    }

    public String getJenis_pesan() {
        return jenis_pesan;
    }

    public void setJenis_pesan(String jenis_pesan) {
        this.jenis_pesan = jenis_pesan;
    }

    public String getStatus() { return status; }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getWaktu_bayar() {
        return waktu_bayar;
    }

    public void setWaktu_bayar(String waktu_bayar) {this.waktu_bayar =  waktu_bayar;}

    public String getGambar_resep() {
        return gambar_resep;
    }

    public void setGambar_resep(String gambar_resep) {
        this.gambar_resep = gambar_resep;
    }

    public String getBukti_bayar() { return bukti_bayar; }

    public void setBukti_bayar(String bukti_bayar) {
        this.bukti_bayar = bukti_bayar;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
