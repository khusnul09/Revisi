package com.example.mynotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.tomergoldst.tooltips.ToolTip;
import com.tomergoldst.tooltips.ToolTipsManager;
import com.varunest.sparkbutton.SparkButton;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class AnotherActivity extends AppCompatActivity {

    TextView mTitleTv, mDescTv, sSatuanTv, tvTitleApriori, tvDescApriori, tvSatuanApriori;
    ImageView mImageIv, ivApriori;
    AdapterRekomendasi rAdapter;//
    RecyclerView recyclerViewRekomendasi;//
    RelativeLayout bawah, atas, dalamnyaBawah, dalamnyaAtas;//
    SparkButton infoButton;
    ToolTipsManager mToolTipsManager;

    String tooltipText = "Produk terkait berisi infomasi tentang obat yang biasanya dibeli secara bersamaan dengan obat diatas. Produk terkait dapat dipesan dengan cara kembali ke halaman pilih obat kemudian cari obat yang diinginkan atau search nama obat, lalu tambahkan obat yang dipilih ke dalam keranjang dan lalukan proses pemesanan sampai selesai.";
    Gson gson;//

    ArrayList<ModelRekomendasi> listRekomendasiObat = new ArrayList<>();//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another);

        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

        mToolTipsManager = new ToolTipsManager();

        mTitleTv = findViewById(R.id.title);
        mDescTv = findViewById(R.id.description);
        mImageIv = findViewById(R.id.imageView);
        sSatuanTv = findViewById(R.id.tv_satuan_obat);
        infoButton = findViewById(R.id.infoButton);

        bawah = findViewById(R.id.layoutBawah);
        atas = findViewById(R.id.layoutAtas);
        dalamnyaBawah = findViewById(R.id.dalamnyaLayoutBawah);
        dalamnyaAtas = findViewById(R.id.dalamnyaLayoutAtas);



        infoButton.setOnClickListener(view -> {
            ToolTip.Builder builder = new ToolTip.Builder(this, infoButton, dalamnyaAtas, tooltipText, ToolTip.POSITION_BELOW);
            builder.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            builder.setTextAppearance(R.style.TooltipTextAppearance);

            mToolTipsManager.show(builder.build());
        });

        /*listRekomendasiObat = getIntent().getParcelableArrayListExtra("CARTS");//
        gson = new Gson();//
        String list = gson.toJson(listRekomendasiObat);//
        Log.d("khatimaLIST", list);//*/

        rAdapter = new AdapterRekomendasi(this, listRekomendasiObat);
        recyclerViewRekomendasi = findViewById(R.id.recyclerViewRekomendasi);
        recyclerViewRekomendasi.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)); // i will create in linearlayout
        recyclerViewRekomendasi.setAdapter(rAdapter);

        /*ivApriori = findViewById(R.id.iv_apriori);
        tvTitleApriori = findViewById(R.id.tv_title_apriori);
        tvDescApriori = findViewById(R.id.tv_harga_apriori);
        tvSatuanApriori = findViewById(R.id.tv_satuan_apriori);*/



        //now get our data from intent in which we put our data

        Intent intent = getIntent();

        String mTitle = intent.getStringExtra("iTitle");
        String mDescription = intent.getStringExtra("iDesc");
        String sSatuan = intent.getStringExtra("satuan");
        String gambar = intent.getStringExtra("gambar");
        String idObat = intent.getStringExtra("id");

        Log.d("khatima", idObat);

        actionBar.setTitle(mTitle); //which title we get from previous activity that will set in our action bar

        //now set our data in our view, which we get in our previous activity
        mTitleTv.setText(mTitle);
        sSatuanTv.setText(sSatuan);
        mDescTv.setText(Rupiah.formatUangId(getApplicationContext(), Double.parseDouble(String.valueOf(mDescription))));

        try {
            //mImageIv.setImageBitmap(bitmap);
            Glide.with(this).load(gambar).into(mImageIv);
        } catch (Exception e) {
            mImageIv.setImageResource(R.drawable.ic_drugs);
        }

        getApriori(idObat);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void getApriori(String idObat) {
        ProgressDialog progressDialog = new ProgressDialog(AnotherActivity.this, ProgressDialog.THEME_HOLO_LIGHT);
        progressDialog.setMessage("Silahkan tunggu..");
        progressDialog.setCancelable(false);
        progressDialog.show();

        int colorWhite = Color.parseColor("#F2F2F2");
        int colorRed = Color.parseColor("#D9303E");
        dalamnyaAtas.setBackgroundColor(colorWhite);
        dalamnyaBawah.setVisibility(View.INVISIBLE);

        String url = "https://obats.000webhostapp.com/index.php/api/Apriori?id=" + idObat;
        Log.d("AnotherActivity", "URL: " + url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        @SuppressLint("CheckResult")
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
            response -> {
                try {
                    JSONArray jsonArray = response.getJSONArray("data");
                    String respon = response.optString("respon");
                    Log.d("AnotherActivity", jsonArray.toString());
                    if (respon.equals("berhasil")) {
                        listRekomendasiObat.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            ModelRekomendasi rekomendasi = new ModelRekomendasi();

                            rekomendasi.setId_obat(jsonArray.getJSONObject(i).optString("id_obat"));
                            rekomendasi.setGambar(jsonArray.getJSONObject(i).optString("gambar"));
                            rekomendasi.setNama_obat(jsonArray.getJSONObject(i).optString("nama_obat"));
                            rekomendasi.setHarga(jsonArray.getJSONObject(i).optString("harga_jual"));
                            rekomendasi.setSatuan(jsonArray.getJSONObject(i).optString("satuan"));

                            listRekomendasiObat.add(rekomendasi);
                        }
                        rAdapter.notifyDataSetChanged();
                        dalamnyaAtas.setBackgroundColor(colorRed);
                        dalamnyaBawah.setVisibility(View.VISIBLE);
                    }

                    if (listRekomendasiObat.size() > 0) {
                        infoButton.setVisibility(View.VISIBLE);
                    } else {
                        infoButton.setVisibility(View.INVISIBLE);
                    }
                    progressDialog.dismiss();

                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                    infoButton.setVisibility(View.INVISIBLE);
                }
            },
            error -> {
                Log.e("AnotherActivity", error.getLocalizedMessage());
                error.printStackTrace();
                progressDialog.dismiss();
                infoButton.setVisibility(View.INVISIBLE);
            }
        );
        requestQueue.add(jsonObjectRequest);
    }
}
