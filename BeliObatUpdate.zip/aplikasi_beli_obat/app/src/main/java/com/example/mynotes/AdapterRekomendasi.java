package com.example.mynotes;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterRekomendasi extends RecyclerView.Adapter<RekomendasiHolder> {

    Context c;
    ArrayList<ModelRekomendasi> listItem;

    public AdapterRekomendasi(Context c, ArrayList<ModelRekomendasi> listItem) {
        this.c = c;
        this.listItem = listItem;
    }

    @NonNull
    @Override
    public RekomendasiHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_rekomendasi, null, false);// this line inflate our row
        return new RekomendasiHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RekomendasiHolder rekomendasiHolder, int i) {
        ModelRekomendasi currentItem = listItem.get(rekomendasiHolder.getAdapterPosition());

        rekomendasiHolder.mTitle.setText(currentItem.getNama_obat()); //here i is position
        rekomendasiHolder.mHarga.setText(Rupiah.formatUangId(c, Double.parseDouble(String.valueOf(currentItem.getHarga()))));
        rekomendasiHolder.mSatuan.setText(currentItem.getSatuan());

        if (!currentItem.getGambar().equals("")) {
            //myHolder.mImaeView.setImageResource(currentItem.getImage());//here we used image resource because we will use images in our
            //myHolder.imageViewResource = currentItem.getImage();
            Glide.with(c).load(currentItem.getGambar()).into(rekomendasiHolder.mImaeView); //tampilkan gambar obat
        } else {
            rekomendasiHolder.mImaeView.setImageResource(R.drawable.ic_drugs);//here we used image resource because we will use images in our
            rekomendasiHolder.imageViewResource = R.drawable.ic_drugs;
        }

        // friends this method is than you can use when you want to use one activity
        // myHolder.setItemClickListener((v, position) -> {        });
    }

    @Override
    public int getItemCount() {
        return listItem.size();
    }
}
