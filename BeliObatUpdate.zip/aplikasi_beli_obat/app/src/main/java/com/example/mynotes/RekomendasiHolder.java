package com.example.mynotes;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RekomendasiHolder extends RecyclerView.ViewHolder {
    ImageView mImaeView;
    TextView mTitle, mHarga, mSatuan;
    int imageViewResource;

    RekomendasiHolder(@NonNull View itemView) {
        super(itemView);

        this.mImaeView = itemView.findViewById(R.id.iv_image_obat_rekomendasi);
        this.mTitle = itemView.findViewById(R.id.tv_nama_obat_rekomendasi);
        this.mHarga = itemView.findViewById(R.id.tv_harga_obat_rekomendasi);
        this.mSatuan = itemView.findViewById(R.id.tv_satuan_rekomendasi);
        imageViewResource = 0;
    }
}
